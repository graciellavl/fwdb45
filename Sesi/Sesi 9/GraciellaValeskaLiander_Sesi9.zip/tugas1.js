// Graciella Valeska Liander

var recipeIndomieSeblakMakaroni = [
    "1. Tumis bumbu halus dengan sedikit minyak",
    "2. masukkan air, setelah mendidih masukkan kocokan telur diaduk",
    "3. masukkan makaroni, lalu sosis kerupuk dan mi, beri gula garam bumbu indomi",
    "4. aduk rata tes rasa angkat sajikan taburi dengan daun bawang.",
];

// Mengakses elemen pertama
console.log(recipeIndomieSeblakMakaroni[0]);

// Mengakses elemen terakhir
var lastStep = recipeIndomieSeblakMakaroni[3];
console.log(lastStep);
