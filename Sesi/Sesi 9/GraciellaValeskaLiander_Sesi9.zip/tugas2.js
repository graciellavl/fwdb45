// Graciella Valeska Liander

var myBucketList = ["Menjadi front end developer", "Memiliki web sendiri"];

console.log("Array awal:");
console.log(myBucketList);

// Menambah item ke paling belakang array
console.log("Push item:");
myBucketList.push("Mendapatkan beasiswa GIT");
console.log(myBucketList);

// Menambah item ke paling depan array
console.log("Unshift item:");
myBucketList.unshift("Mendaftar beasiswa GIT");
console.log(myBucketList);

// Menghapus item paling belakang array
console.log("Pop item:");
myBucketList.pop();
console.log(myBucketList);

// Menghapus item paling depan array
console.log("Shift item:");
myBucketList.shift();
console.log(myBucketList);

console.log("Array akhir:");
console.log(myBucketList);
